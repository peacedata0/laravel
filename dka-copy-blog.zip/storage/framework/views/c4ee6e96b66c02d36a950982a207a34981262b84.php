<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>#peace_data, it's my first laravel page! \(^_^)/</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Handlee&effect=anaglyph|3d-float" rel="stylesheet">
    <script src="https://intita.com/api/dist/intita-api-client.min.js" type="text/javascript"></script>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" > -->
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keyword'); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description'); ?>">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::to('css/css_1.css')); ?>" rel="stylesheet" type="text/css">

</head>
<body>
    <div id="app">
        <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(URL::to('js/js_1.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
