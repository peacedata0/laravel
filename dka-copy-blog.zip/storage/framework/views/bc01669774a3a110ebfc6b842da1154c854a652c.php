<label for="">Status</label>
<select class="form-control" name="published">
  <?php if(isset($article->id)): ?>
    <option value="0" <?php if($article->published == 0): ?> selected="" <?php endif; ?>>Not Published</option>
    <option value="1" <?php if($article->published == 1): ?> selected="" <?php endif; ?>>Published</option>

  <?php else: ?>
  <option value="0">Not Published</option>
  <option value="1">Published</option>

  <?php endif; ?>
</select>

<label for="">Title</label>
<input type="text" class="form-control" name="title" placeholder="News Title"
value="<?php echo e(isset($article->title) ? $article->title : ""); ?>" required>

<label for="">Slug (unique)</label>
<input class="form-control" type="text" name="slug" placeholder="Auto Generate"
value="<?php echo e(isset($article->slug) ? $article->slug : ""); ?>" readonly>

<label for="">Parent Category</label>
<select class="form-control" name="categories[]" multiple="">
  <?php echo $__env->make('admin.articles.partials.categories', ['categories' => $categories], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</select>

<label for=""> Short Description </label>
<textarea class="form-control" id="description_short" name="description_short" >
<?php echo e(isset($article->description_short) ? $article->description_short : ""); ?>

</textarea>

<label for=""> Full Description </label>
<textarea class="form-control" id="description" name="description" >
<?php echo e(isset($article->description) ? $article->description : ""); ?>

</textarea>

<hr/>

<label for="">Meta Title</label>
<input type="text" class="form-control" name="meta_title" placeholder="Meta Title"
value="<?php echo e(isset($article->meta_title) ? $article->meta_title : ""); ?>" required>

<label for="">Meta Description</label>
<input type="text" class="form-control" name="meta_description" placeholder="Meta Description"
value="<?php echo e(isset($article->meta_description) ? $article->meta_description : ""); ?>" required>

<label for="">Keywords</label>
<input type="text" class="form-control" name="meta_keywords" placeholder="Keywords with commas"
value="<?php echo e(isset($article->meta_keywords) ? $article->meta_keywords : ""); ?>" required>

<hr/>

<input class="btn btn-primary" type="submit" value="Save">
