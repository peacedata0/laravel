<label for="">Status</label>
<select class="form-control" name="published">
  <?php if(isset($category->id)): ?>
    <option value="0" <?php if($category->published == 0): ?> selected="" <?php endif; ?>>Not Published</option>
    <option value="1" <?php if($category->published == 1): ?> selected="" <?php endif; ?>>Published</option>

  <?php else: ?>
  <option value="0">Not Published</option>
  <option value="1">Published</option>

  <?php endif; ?>
</select>

<label for="">Article</label>
<input type="text" class="form-control" name="title" placeholder="Article Name"
value="<?php echo e(isset($category->title) ? $category->title : ""); ?>" required>

<label for="">Slug</label>
<input class="form-control" type="text" name="slug" placeholder="Auto Generate"
value="<?php echo e(isset($category->slug) ? $category->slug : ""); ?>" readonly>

<label for="">Parent Category</label>
<select class="form-control" name="parent_id">
  <option value="0">-- without parent category --</option>
  <?php echo $__env->make('admin.categories.partials.categories', ['categories' => $categories], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</select>

<hr/>

<input class="btn btn-primary" type="submit" value="Save">
